//
//  Airlines Enquiry.swift
//  Flight class
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
var enquiry Id: String?
var enquiry type: String?
var enquiry title: String?
var enquiry description : String?
var FlightairlineId : String?
var Airline : String?
//stored property

var FlightName : String?{
    get{
        return self.FlightName
        
    }
    set{
        
        self.FlightName = newValue
    }
    
}

var  FlightID: String?{
    get{
        return self.FlightID
    }
    set{
        self.FlightID = newValue
    }
}

var FlightFrom : String?{
    get{
        return self.FlightFrom
    }
    set{
        self.FlightFrom = newValue
    }
}

var FlightTo: String?{
    get{
        return self.FlightTo
    }
    set{
        self.FlightTo = newValue
    }
}
var DateFlightSchedule : String?{
    get{
        return self.DateFlightSchedule
    }
    set{
        self.DateFlightSchedule = newValue
    }
}
var  FlightSchduleDate : String?{
    get{
        return self.FlightSchduleDate
    }
    set{
        self.FlightSchduleDate = newValue
    }
}

var   FlightAirlineId: String?{
    get{
        return self.FlightAirlineId
    }
    set{
        self.FlightAirlineId = newValue
    }
}

var private var FlightAirplaneId: String?{
    get{
        return self.FlightAirplaneId : String?
    }
    set{
        self.FlightAirplaneId : String? = newValue
    }
}








init() {
    self.FlightID  = ""
    self.FlightFrom = ""
    self.FlightTo = ""
    self.DateFlightSchedule = ""
    self.FlightSchduleDate = ""
    self.FlightAirlineId = ""
    self.FlightAirplaneId = ""
    self.FlightPilotId = ""
    
}
