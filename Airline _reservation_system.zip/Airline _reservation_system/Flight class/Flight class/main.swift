//
//  main.swift
//  Flight class
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

class Flight{
    var FlightID : String?
    var FlightFrom : String
    var FlightTo : String?
    var DateFlightSchedule : String?
    var FlightairlineId : String?
    var FlightSchduleDate : Date?
     var FlightAirlineId : Int?
     var FlightAirplaneId: String?
     var FlightPilotId: String?
    
    //stored property
    
    var FlightName : String?{
        get{
            return self.FlightName
            
        }
        set{
            
            self.FlightName = newValue
        }
        
    }
    
    var  flightID: String?{
        get{
            return self.FlightID
        }
        set{
            self.FlightID = newValue
        }
    }
    
    var flightFrom : String?{
        get{
            return self.FlightFrom
        }
        set{
            self.flightFrom = newValue
        }
    }
    
    var flightTo: String?{
        get{
            return self.FlightTo
        }
        set{
            self.FlightTo = newValue
        }
    }
    var dateFlightSchedule : String?{
        get{
            return self.DateFlightSchedule
        }
        set{
            self.DateFlightSchedule = newValue
        }
    }
    var  flightSchduleDate : String?{
    get{
        return self.flightSchduleDate
    }
    set{
        self.flightSchduleDate = newValue
    }
    }
    
    var   flightAirlineId: String?{
        get{
            return self.flightAirlineId
        }
        set{
            self.flightAirlineId = newValue
        }
    }
    
    var flightAirplaneId: String?{
        get{
            return self.flightAirplaneId
        }
        set{
            self.flightAirplaneId = newValue
        }
    }
    
    
    
    
    
    
    
    
    init() {
        self.FlightID  = ""
        self.FlightFrom = ""
        self.FlightTo = ""
        self.DateFlightSchedule = ""
       // self.FlightSchduleDate = ""
        self.FlightAirlineId = 0
        self.FlightAirplaneId = ""
        self.FlightPilotId = ""
    }
}
